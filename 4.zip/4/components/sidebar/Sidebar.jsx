"use client";
import React from "react";
import "./Sidebar.css";
import Link from "next/link";
import Image from "next/image";
import { IconName } from "react-icons/fa";
import { FaComment } from "react-icons/fa";
import { FaRegUser } from "react-icons/fa";
import { MdOutlineProductionQuantityLimits } from "react-icons/md";
import { usePathname } from "next/navigation";

const Sidebar = () => {
  const pathname = usePathname();
  return (
    <div className="sidebar">
      <ul className="sidebar-list">
        <li>
          <Link
            className={pathname === "/dashboard/users" ? "link active" : "link"}
            href={"/dashboard/users"}
          >
            <FaRegUser />
            <span>Users</span>
          </Link>
        </li>
        <li>
          <Link
            className={
              pathname === "/dashboard/products" ? "link active" : "link"
            }
            href={"/dashboard/products"}
          >
            <MdOutlineProductionQuantityLimits />
            <span>Products</span>
          </Link>
        </li>
        <li>
          <Link
            className={
              pathname === "/dashboard/comments" ? "link active" : "link"
            }
            href={"/dashboard/comments"}
          >
            <FaComment />
            <span>Comments</span>
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
