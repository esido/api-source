import React from "react";
import "./page.css";

const fetchProducts = () => {
  return fetch("https://api.escuelajs.co/api/v1/products")
    .then((response) => response.json())
    .then((data) => data);
};

const page = async () => {
  const data = await fetchProducts();
  return (
    <div className="products-container">
      {data.map((product) => (
        <div key={product.id} className="product-card">
          <img src={product.images[0]} alt="" class="product-img" />
          <div class="product-info">
            <h3 class="product-name">{product.title}</h3>
            <p class="product-description">{product.description}</p>
            <span class="product-price">Price: {product.price}$</span>
          </div>
        </div>
      ))}
    </div>
  );
};

export default page;
